# sort numbers and letters

## Objectives

1. Understand the return value of the each method


## Instructions


For example:

```ruby
reverse_each_word("Hello there, and how are you?")
  #=> "olleH ,ereht dna woh era ?uoy"
```

